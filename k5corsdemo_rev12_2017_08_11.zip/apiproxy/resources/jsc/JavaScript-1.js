//context.setVariable("target.copy.pathsuffix", true);
//context.setVariable("target.copy.queryparams", false);
 
//var targetUrl = context.getVariable("proxy.pathsuffix");
 //get the path suffix
//var pathsuffix = context.getVariable("proxy.pathsuffix");
 
//context.setVariable("target.url", targetUrl);
//get zipcode value already extracted
var k5endpoint=context.getVariable("k5endpoint");

//frame target_url
var target_url="https:/"+k5endpoint;

//assign to target.url flow variable
context.setVariable("target.url",target_url);