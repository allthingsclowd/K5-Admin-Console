if (context.flow=="PROXY_REQ_FLOW") {
     var k5endpoint = context.getVariable("proxy.pathsuffix");
     context.setVariable("k5endpoint", k5endpoint);
}
